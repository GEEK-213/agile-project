package lab28_3_25;

class Bag1 {
    private String color;
    private int pockets;
    private int price;

    Bag1(String c, int p, int pr) {
        color = c;
        pockets = p;
        price = pr;
    }

    void display() {
        System.out.println("Color of bag: " + color);
        System.out.println("No. of pockets: " + pockets);
        System.out.println("Price of bag: " + price);
        System.out.println();
    }
}

public class Bag {
    public static void main(String[] args) {
        Bag1 b1 = new Bag1("Black", 5, 2500);
        Bag1 b2 = new Bag1("Grey", 7, 3500);

        b1.display();
        b2.display();
    }
}

