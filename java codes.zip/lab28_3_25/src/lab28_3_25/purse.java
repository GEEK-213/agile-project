package lab28_3_25;

class purse1{
	private String color;
	private int pocket;
	private int price;
	purse1 (String c, int p, int pr){
		color = c;
		pocket = p;
		price = pr;
	}
	void display() {
		System.out.println("color of purse:" + color);
		System.out.println("No. pocket of purse:" + pocket);
		System.out.println("price of purse:" + price);
		System.out.println('\n');
	}
}

public class purse {
	public static void main(String[] args) {
		purse1 o = new purse1("red", 4, 12000);
		purse1 o1 = new purse1("blue", 6, 20000);
		
		o.display();
		o1.display();
	}

}
