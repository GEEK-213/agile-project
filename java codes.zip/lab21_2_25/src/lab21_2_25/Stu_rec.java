package lab21_2_25;
import java.util.Scanner;

public class Stu_rec {
	String name;
	int roll;
	String Class;
	Float percent;
	
	Stu_rec(){
		this.name = "null";
		this.roll = 0;
		this.Class = "null";
		this.percent = (float) 0;
	}
	
	void Read(String n,int r,String c,Float p) {
		name = n;
		roll = r;
		Class = c;
		percent = p;
	}
	
	void Display() {
		System.out.println("\nName is : "+name);
		System.out.println("\nRollNo. is : "+roll);
		System.out.println("\nClass is : "+Class);
		System.out.println("\npercentage is : "+percent+"%");
	}
	

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		Stu_rec o = new Stu_rec();
	    System.out.println("Enter name:");
	    String name = s.nextLine();

	    System.out.println("Enter roll number:");
	    int roll = s.nextInt();
	    s.nextLine();

	    System.out.println("Enter class:");
	    String className = s.nextLine();

	    System.out.println("Enter percentage:");
	    float percent = s.nextFloat();

	    o.Read(name, roll, className, percent);
	    o.Display();

	    s.close();
	}
}
