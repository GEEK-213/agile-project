package lab21_2_25;

public class Car_class {
	private String brand;
	private String model;
	private int price;
	
	void SD(String b,String m, int p) {
		brand = b;
		model = m;
		price = p;
	}
	
	void Display(int count) {
		System.out.println("Car "+count+" :Brand - "+brand+" , Model - "+model+" , Price - "+price);
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Car_class o = new Car_class();
		Car_class o1 = new Car_class();
		
		o.SD("Toyota", "Foutuner", 5000000);
		o1.SD("Honda", "Civic", 2500000);
		
		o.Display(1);
		o1.Display(2);
	}

}
