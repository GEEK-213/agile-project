package lab21_2_25;
import java.util.Scanner;

public class Bank_acc {
	private int accNo;
	private String HoldName;
	private int balance;
	
	void deposit(int m) {
		System.out.println("Deposit Amount: "+m);  
		balance+=m;
	}
	
	void withdraw(int take) {
		System.out.println("Withdraw Amount: "+take);
		balance-=take;
	}
	
	void display() {
		System.out.println("Updated Balance: "+balance);
	}
	

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		Bank_acc Ac = new Bank_acc();
		
		System.out.print("Enter Account Number: ");
		Ac.accNo = s.nextInt();
		System.out.print("\nEnter Account Holder Name: ");
		Ac.HoldName = s.next();
		System.out.print("\nEnter Initial Balance\n");
		Ac.balance = s.nextInt();
		
		System.out.print("\nEnter deposit Amount\n");
		Ac.deposit(s.nextInt());
		Ac.display();
		System.out.print("\nEnter Withdraw Amount\n");
		Ac.withdraw(s.nextInt());
		Ac.display();
		
		s.close();
	}

}
