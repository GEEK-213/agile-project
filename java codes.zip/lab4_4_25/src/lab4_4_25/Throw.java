package lab4_4_25;

public class Throw {
	static void checkAge(int age) {
		if(age < 18) {
			throw new ArithmeticException("You cannot access this site");
		}
		else {
			System.out.println("Welcome");
		}
	}
	public static void main(String[] args) {
		checkAge(17);
	}
} 