package lab4_4_25;

public class StringOutOfBounds {

	public static void main(String[] args) {
		try {
			String str = "mail";
			System.out.println(str.charAt(10));
		} catch(StringIndexOutOfBoundsException e) {
			System.out.println("char not found on str");
		}
	}

}
