package lab4_4_25;

public class indexOutOfBounds {

	public static void main(String[] args) {
		try {
			int[] nums  = {1,2,3};
			System.out.println(nums[5]);
			int res = 10/0;
			System.out.println(res);
		}
		catch(ArrayIndexOutOfBoundsException e) {
			System.out.println("array out of bounds");
		}
		catch(ArithmeticException e) {
			System.out.println("cannot divide by zero");
		}
		catch(Exception e) {
			System.out.println("Some Exception");
		}

	}

}
