package lab4_4_25;

public class NullPointer {

	public static void main(String[] args) {
		try {
			int[] nums = null;
			System.out.println(nums.length);
		} catch (NullPointerException e) {
			System.out.println("nums does not exist");
		}
		
	}

}
