package lab4_4_25;

public class Finally {

	public static void main(String[] args) {
		try {
			int res = 20/0;
			System.out.println(res);
		} catch(ArithmeticException e) {
			System.out.println("cannot divide by 0");
		} finally {
			System.out.println("Wow");
		}

	}

}
