package lab4_4_25;

public class Try_catch {

	public static void main(String[] args) {
		try {
			int res = 10/0;
			System.out.println(res);
		}
		catch(ArithmeticException e){
			System.out.println("Cannot divide by 0");
		}
		System.out.println("continues");

	}
}
