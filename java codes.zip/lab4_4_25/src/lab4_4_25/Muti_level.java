package lab4_4_25;

class Wrist_watch{
	String color;
	int price;
	void getter(String c, int p) {
		
	}
	void setter() {
			
		}
} 

public class Muti_level {

	public static void main(String[] args) {
		

	}

}
