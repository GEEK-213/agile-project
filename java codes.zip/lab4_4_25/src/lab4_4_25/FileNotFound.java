package lab4_4_25;
import java.io.File; 
import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class FileNotFound {

	public static void main(String[] args) {
		        String fileName = "file does not exist"; 
		        File file = new File(fileName);
		        try {
		            FileInputStream stream = new FileInputStream(file); 
		        } catch (FileNotFoundException e) {
		            e.printStackTrace();
		        }
			}
}



