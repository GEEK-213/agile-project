package lab31_1_25;

public class Break {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=6;
		
		for(int i=0;i<10;)
		{
			a+=1;
			break;
		}
		System.out.println(a); //answer will be 7
	}

}
