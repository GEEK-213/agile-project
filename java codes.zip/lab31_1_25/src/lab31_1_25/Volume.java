package lab31_1_25;

public class Volume {
    public int volume(int width, int height, int depth) {
        return width * height * depth;
    }

    public static void main(String[] args) {
        Volume a = new Volume();
        int res = a.volume(10, 8, 16);
        System.out.println("The volume is: " + res);
    }
}
