package lab31_1_25;

public class Contine {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=6;
		
		for(int i=0;i<10; i++)
		{
			a+=1;
			continue;
		}
		for(int j=0;j<5; j++)
		{
			a+=1;
		}
		
		System.out.println(a); //answer will be 21
	}
}


