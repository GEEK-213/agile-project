package lab28_2_25;
import java.util.Scanner;

public class student_arr_of_objs {
	private String name;
	private int age;
	private char grade;
	
	void setdata(String n,int a, char g) {
		name = n;
		age = a;
		grade = g;
	}
	
	void display(int count) {
		System.out.println("Enter details for Student "+count+" :");
		System.out.println("Name: "+name+"\nAge: "+age+"\nGrade: "+grade);
	}

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		student_arr_of_objs[] o = new student_arr_of_objs[3];
		
		for (int i=0; i<3; i++) {
			o[i] = new student_arr_of_objs();
			System.out.println("Enter Name :");
			String n = s.next();
			System.out.println("Enter Age :");
			int a = s.nextInt();
			System.out.println("Enter Grade: ");
			char g = s.next().charAt(0);
			o[i].setdata(n, a, g);
		}
		
		for (int i=0; i<3; i++) {
			o[i].display(i + 1);
		}
		s.close();
	}

}
