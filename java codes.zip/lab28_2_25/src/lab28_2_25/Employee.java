package lab28_2_25;
import java.util.Scanner;

public class Employee {
	private String name;
	private int id;
	private int salary;
	
	void SD(String n, int i, int s) {
		name = n;
		id = i;
		if(s < 0) {
			System.out.println("Invaild Input\n");
			salary = 0;
		} else {
			salary = s;
		}
	}
	
	void D() {
		System.out.println("Employee Details:");
		System.out.println("Name: "+name+"\nID: "+id+"\nSalary: "+salary);	
	}

	public static void main(String[] args) {
		Employee o = new Employee();
		Scanner s = new Scanner(System.in);
		
		System.out.println("Enter Name :");
		String n = s.next();
		System.out.println("Enter ID :");
		int a = s.nextInt();
		System.out.println("Enter Salary: ");
		int s1 = s.nextInt();
		
		o.SD(n, a, s1);
		
		o.D();
		
		s.close();
	}

}
