package lab28_2_25;
import java.util.Scanner;

public class Library {
	private String title;
	private String author;
	private int availableCopies;
	
	void setdata(String t, String a, int av) {
		title = t;
		author = a;
		availableCopies = av;
	}
	
	int Borrowbook() {
		availableCopies--;
		return availableCopies;
	}
	
	void display() {
	    System.out.println("Title: " + title);
	    System.out.println("Author: " + author);
	    System.out.println("Available Copies: " + availableCopies);
	}

	int returnbook() {
		availableCopies++;
		return availableCopies;
	}
	
	public static void main(String[] args) {
		 Scanner s = new Scanner(System.in);
		 Library[] o = new Library[3];
		 
			for (int i=0; i<3; i++) {
				o[i] = new Library();
				System.out.println("Enter Title :");
				String t = s.next();
				System.out.println("Enter Author :");
				String a = s.next();
				System.out.println("Enter No.Copies: ");
				int av = s.nextInt();
				o[i].setdata(t, a, av);
			}
			
			System.out.println("Do you want to borrow this book?");
			o[1].display();
			
			s.close();
	}

}
