package lab28_2_25;
import java.util.Scanner;

public class Product {
	private String name;
	private int price;
	private int discount;
	
	void SD(String n, int p, int d) {
		name = n;
		price = p;
		discount = d;
	}
	void D(int Dis) {
		System.out.println("Final price after discount :"+Dis);
	}
	
	int calculateDiscount(int p, float dis) {
		int disco = p;
		dis /=100;
		disco*=dis;
		return discount = price - disco;
	}

	public static void main(String[] args) {
		Product o = new Product();
		Scanner s = new Scanner(System.in);
		
		System.out.println("Enter Name :");
		String n = s.next();
		System.out.println("Enter Price :");
		int a = s.nextInt();
		System.out.println("Enter Discount: ");
		int s1 = s.nextInt();
		
		o.SD(n, a, s1);
		
		o.calculateDiscount(a, s1);
		
		o.D(o.discount);
		
		s.close();

	}

}
