package lab14_2_25;
import java.util.Scanner;

class Books{
	String brand;
	int pages;
	int price;

	public void arrayofbooks(String b, int p, int pr) {
		brand = b;
		pages = p;
		price = pr;
	}
	public void display() {
		System.out.println("Brand:"+brand+"\nPages: "+pages+"\nPrice "+price);
	}
	
}

public class Class_book {

	public static void main(String[] args) {
		Books b1 = new Books();
		b1.arrayofbooks("Penguin", 300, 450);
		b1.display();
	}

}
