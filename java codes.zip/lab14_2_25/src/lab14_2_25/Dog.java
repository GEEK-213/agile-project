package lab14_2_25;
import java.util.Scanner;

class Dogs {
    static String Dog_breed;
    static String Dog_size;
    static int Dog_age;

    static void breed() {
        Scanner s = new Scanner(System.in);
        System.out.println("Which breed is it?");
        Dog_breed = s.nextLine();
    }

    static void size() {
        Scanner s = new Scanner(System.in);
        System.out.println("How big is it: small, medium, or large?");
        Dog_size = s.nextLine();
    }

    static void age() {
        Scanner s = new Scanner(System.in);
        System.out.println("What's its age?");
        Dog_age = s.nextInt();
    }

    static void display() {
        System.out.println("Breed of Dog is " + Dog_breed);
        System.out.println("Size of Dog is " + Dog_size);
        System.out.println("Age of Dog is " + Dog_age); 
    }
}

public class Dog {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(int i=0;i<2;i++) {
				Dogs.breed();
				Dogs.size();
				Dogs.age();
				Dogs.display();
		}
	}
}
