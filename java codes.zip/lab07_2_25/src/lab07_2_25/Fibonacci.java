package lab07_2_25;

public class Fibonacci {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int fib1 = 0;
		int fib2 = 1;
		int next;
		for(int i=0;i<=10;i++)
		{
			next = fib1+fib2;
			System.out.println(next);
			fib1 = fib2;
			fib2 = next;
		}
		

	}

}
