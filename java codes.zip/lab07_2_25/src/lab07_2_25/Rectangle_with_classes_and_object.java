package lab07_2_25;
import java.util.Scanner;

class read_calculate_display {
    public double r() {
        Scanner s = new Scanner(System.in);
        System.out.println("Enter a length in cm:");
        double len = s.nextInt();
        System.out.println("Enter a breath in cm:");
        double bre = s.nextInt();
        s.close();
        return len * bre;
    }
    
    public void c() {
        double res = r();
        System.out.println(res);
    }
}

public class Rectangle_with_classes_and_object {
    public static void main(String[] args) {
        read_calculate_display display = new read_calculate_display();
        display.c();
    }
} 


