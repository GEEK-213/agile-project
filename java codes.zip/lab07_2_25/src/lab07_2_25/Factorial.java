package lab07_2_25;
import java.util.Scanner;

class fact{
	int ff (int n) {
		int fact =1;
		for (int i=1;i<=n;i++) {
			fact*=i;
		}
		return fact;
	}
}

public class Factorial {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		fact cal = new fact();
		Scanner s =new Scanner(System.in);
		System.out.println("Enter a number");
		int n = s.nextInt();
		System.out.println(cal.ff(n));
		s.close();
	}

}
