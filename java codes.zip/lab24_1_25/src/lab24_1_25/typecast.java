package lab24_1_25;

public class typecast {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x= 2;
		float y=4;
		int sum=(int) y/x;
		System.out.println("4.0/2 = "+(sum));
	}
}
