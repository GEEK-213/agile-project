package lab24_1_25;

public class xyz_operators {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=10,b=23,c=9 ;
		System.out.println("X= " +(a*b-c));
		System.out.println("Y= " +(b/c*a));
		System.out.println("Z= " +(a-b/c+b));
	}

}
